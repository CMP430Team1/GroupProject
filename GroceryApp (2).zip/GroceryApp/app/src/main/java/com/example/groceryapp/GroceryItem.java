package com.example.groceryapp;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "groceryItem_table"/*, foreignKeys = {@ForeignKey(
        entity = UserCart.class,
        parentColumns = "id",
        childColumns = "userCartIdFk"
)}*/)

public class GroceryItem implements Parcelable {

    @NonNull
    @PrimaryKey(autoGenerate = true)
    protected int groceryItemId;

    //Foreign key
    //@ColumnInfo(name = "userCart_ForeignKey")
    protected int userCartId;

    @ColumnInfo(name = "Item_Name")
    protected String itemName;

    @ColumnInfo(name = "Item_Price")
    protected double itemPrice;

    @ColumnInfo(name = "Item_Category")
    protected String itemCategory;

    @ColumnInfo(name = "Item_Description")
    protected String itemDescription;

    public GroceryItem(String itemName, double itemPrice, String itemCategory, String itemDescription) {
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.itemCategory = itemCategory;
        this.itemDescription = itemDescription;
    }

    protected GroceryItem(Parcel in) {
        groceryItemId = in.readInt();
        userCartId = in.readInt();
        itemName = in.readString();
        itemPrice = in.readDouble();
        itemCategory = in.readString();
        itemDescription = in.readString();
    }

    public static final Creator<GroceryItem> CREATOR = new Creator<GroceryItem>() {
        @Override
        public GroceryItem createFromParcel(Parcel in) {
            return new GroceryItem(in);
        }

        @Override
        public GroceryItem[] newArray(int size) {
            return new GroceryItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(groceryItemId);
        parcel.writeInt(userCartId);
        parcel.writeString(itemName);
        parcel.writeDouble(itemPrice);
        parcel.writeString(itemCategory);
        parcel.writeString(itemDescription);
    }

    //    public GroceryItem(@NonNull String name, @NonNull double price, @NonNull String description){
//        itemName        = name;
//        itemPrice       = price;
//        itemDescription = description;
//    }


//    public int getId() {
//        return id;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public String getItemName(){
//        return itemName;
//    }
//
//    public double getItemPrice(){
//        return itemPrice;
//    }
//
//    public String getItemCategory(){
//        return itemCategory;
//    }
//
//    public String getItemDescription(){
//        return itemDescription;
//    }
//
//
//    public void setItemName(String newName){
//        itemName =  newName;
//    }
//
//    public void setItemPrice(double newPrice){
//        itemPrice = newPrice;
//    }
//
//    public void setItemCategory(String newCategory){
//        itemCategory = newCategory;
//    }
//
//    public void setItemDescription(String newDescription){
//        itemDescription = newDescription;
//    }
}
