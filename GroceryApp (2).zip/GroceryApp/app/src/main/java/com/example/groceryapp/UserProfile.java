package com.example.groceryapp;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "UserProfile_table")
public class UserProfile {
    @NonNull
    @PrimaryKey
    @ColumnInfo(name = "Name")
    protected String userName;

    @ColumnInfo(name = "Phone")
    protected String userPhone;

    @ColumnInfo(name = "Address")
    protected String userAddress;

    @ColumnInfo(name = "City")
    protected String userCity;

    @ColumnInfo(name = "States")
    protected String userState;

    protected String userZip;

    public UserProfile(String userName, String userPhone, String userAddress, String userCity, String userState, String userZip) {
        this.userName = userName;
        this.userPhone = userPhone;
        this.userAddress = userAddress;
        this.userCity = userCity;
        this.userState = userState;
        this.userZip = userZip;
    }
}
