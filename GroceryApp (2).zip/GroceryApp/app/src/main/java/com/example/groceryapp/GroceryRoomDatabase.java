package com.example.groceryapp;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {GroceryItem.class, UserCart.class, UserProfile.class}, version = 2, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class GroceryRoomDatabase extends RoomDatabase {
    public abstract GroceryDao groceryDao();
    public abstract CartDao cartDao();
    public abstract UserDao userDao();

    private static GroceryRoomDatabase INSTANCE;

    public static GroceryRoomDatabase getDatabase(final Context context){
        if(INSTANCE == null){
            synchronized (GroceryRoomDatabase.class){
                if(INSTANCE == null){
                    // Create DB here
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            GroceryRoomDatabase.class, "groceryApp_database")
                            //wipes & rebuilds instead of migrating
                            // look into migration
                            .fallbackToDestructiveMigration()
                            .addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static GroceryRoomDatabase.Callback sRoomDatabaseCallback =
            new RoomDatabase.Callback(){
                @Override
                public void onOpen(@NonNull SupportSQLiteDatabase db) {
                    super.onOpen(db);
                    new PopulateDbAsync(INSTANCE).execute();
                }
            };

    private static class PopulateDbAsync extends AsyncTask<Void, Void, Void> {

        private final GroceryDao mDao;
        GroceryItem[] items = createItemList();

        public GroceryItem[] createItemList(){
            String[] /*frozen*/Goods = {"Peas", "Mixed Vegetables", "Broccoli", "Ice Cream", "Ice", "Pizza", "Chicken", "Beef", "Pork", "Fish",
            /*String[] freshGoods = {*/"Lettuce", "Cabbage", "Broccoli", "Orange", "StrawBerry", "Fish", "Kale", "Carrot", "Cauliflower", "Spinach",
            /*String[] cannedGoods = {*/"Beans", "Peas", "Soup", "Mixed Vegetables", "Chick-Peas", "Tuna", " Mixed Fruits", "Cherries", "Bread", "Pineapples"};
            GroceryItem[] itemList = new GroceryItem[30];
            for(int i = 0; i < itemList.length; i++){
                /*if(i < 10){
                    itemList[i] = new GroceryItem(frozenGoods[i], (double)i, "frozen","This is frozen " + frozenGoods[i]);
                }
                if(i > 10 && i < 20){
                    itemList[i] = new GroceryItem( freshGoods[i], (double)i, "fresh","This is fresh " + freshGoods[i]);
                }
                if(i >= 20 && i < 30){
                    itemList[i] = new GroceryItem(cannedGoods[i], (double)i, "canned","This is canned " + cannedGoods[i]);
                }*/
                if(i <= 10){
                    itemList[i] = new GroceryItem(Goods[i], (double)i, "frozen","This is " + Goods[i]);
                }else if(i > 10 && i < 20){
                    itemList[i] = new GroceryItem(Goods[i], (double)i, "fresh","This is " + Goods[i]);
                }else if(i >=20 && i < 30){
                    itemList[i] = new GroceryItem(Goods[i], (double)i, "canned","This is " + Goods[i]);
                }

            }
            return itemList;
        }

        public PopulateDbAsync(GroceryRoomDatabase db) {
            mDao = db.groceryDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            mDao.deleteAll();

            for(int i = 0; i <= items.length - 1; i++){
                mDao.insert(items[i]);
            }

            return null;
        }
    }
}
